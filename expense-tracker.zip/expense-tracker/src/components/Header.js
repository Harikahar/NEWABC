import React from 'react'

export const Header = () => {
    return (
        <h2>
            Expense Tracker
        </h2>
    )
}
